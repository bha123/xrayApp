import os
from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
import tensorflow as tf  
import numpy as np 

class_names = ['NORMAL', 'PNEUMONIA'] 


UPLOAD_FOLDER = os.path.join(os.getcwd(),'data')
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS



def predictPicture(file_path):
    img = tf.keras.utils.load_img( 
        path_normal, target_size=(256, 256) 
    ) 
    img_array = tf.keras.utils.img_to_array(img) 
    img_array = tf.expand_dims(img_array, 0) # Create a ba 
    print(img_array) 
    print(img_array.shape) 
    new_model = tf.keras.models.load_model('Save_model.h5') 
    predictions = new_model.predict(img_array) 
    score = tf.nn.softmax(predictions[0]) 
    print(np.argmax(score)) 
    output =  ("This image most likely belongs to {} with a {:.2f} percent confidence." .format(class_names[np.argmax(score)], 100 * np.max(score))) 
    return output

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        print(file.filename)
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            predicted_output = predictPicture(filepath)
            return render_template('output.html',data=predicted_output)
            #return redirect(url_for('download_file', name=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''